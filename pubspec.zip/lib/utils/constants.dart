class Constants {
  static const userFavoritesUrl =
      'https://cadastro-escola-default-rtdb.firebaseio.com/userFavorites';
  static const productBaseUrl =
      'https://cadastro-escola-default-rtdb.firebaseio.com/products';
  static const orderBaseUrl =
      'https://cadastro-escola-default-rtdb.firebaseio.com/orders';
  static const webApiKey = 'AIzaSyDSu-m0wMt47lvthEl1s_gXc_F0N_ExjJY';
}
